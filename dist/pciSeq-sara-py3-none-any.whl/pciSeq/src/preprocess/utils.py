
def get_img_shape(coo):
    w = coo.shape[1]
    h = coo.shape[0]
    return [h, w]