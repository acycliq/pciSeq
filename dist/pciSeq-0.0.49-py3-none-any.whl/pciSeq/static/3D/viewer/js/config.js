function config() {
    return {
            img_width: 5905,
            img_height: 5882,
            img_depth: 15 * 6.0121,
            particle_size: 8000.0,
            geneData: {mediaLink: '../../data/geneData.tsv', size: "65755002"},
            cellData: {mediaLink: '../../data/cellData.tsv', size: "10554015"},
        }
}