class parking():
    clients = set()

    def plus_one(self):
        self.clients.add(self)


if __name__ == "__main__":
    p = parking()
    for i in range(3):
        p.plus_one()
        print(len(parking.clients))
