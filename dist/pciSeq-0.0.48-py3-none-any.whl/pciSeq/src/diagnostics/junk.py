from server import WebSocketServer

def main():
    WebSocketServer.send_message(str(1232))
    print('ok')

if __name__ == "__main__":
    main()