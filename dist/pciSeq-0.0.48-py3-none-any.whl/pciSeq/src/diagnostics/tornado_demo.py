import client
import server

def main():
    tornado_client.main()
    tornado_server.main()

if __name__ == "__main__":
    main()
