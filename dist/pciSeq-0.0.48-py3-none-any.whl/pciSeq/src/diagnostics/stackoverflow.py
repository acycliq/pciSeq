import asyncio
from datetime import datetime

async def do_some_iterations():
    for i in range(10):
        print(datetime.now().time())
        await asyncio.sleep(1)
    print('... Cool!')

async def do_something():
    print('something...')

async def main():
    task = asyncio.create_task(do_some_iterations())
    task2 = asyncio.create_task(do_something())
    await task
    await task2

if __name__ == "__main__":
    asyncio.run(main())
    print("done")